package com.example.assignment.ui.theme.screens

// Tabs for Sales area
enum class SalesTab { Home, Add, Commission, Orders }

